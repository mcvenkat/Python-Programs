#!/bin/bash

python step11_final/blending_n_postprocessing.py
