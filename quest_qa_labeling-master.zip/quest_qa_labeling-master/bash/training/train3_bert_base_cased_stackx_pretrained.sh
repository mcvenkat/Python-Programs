#!/bin/bash

toy=${1:-False}

python step3_model1_bert_code/train.py $toy
