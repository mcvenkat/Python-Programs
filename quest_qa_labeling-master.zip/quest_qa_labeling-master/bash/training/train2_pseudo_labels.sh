#!/bin/bash

# actually not needed here, just for consistency
sh bash/pseudo/create_all_pseudo_labels.sh