#!/bin/bash

python step1_lm_finetuning/train_stackx_lm.py